package com.meetpules.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Gold = Color(0xFFD6AD55)
private val GoldLight = Color(0xFFFFDF91)
private val Black = Color(0xFF090909)
private val Panel = Color(0xFF171717)
private val Muted = Color(0xFFAAAAAA)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MeetpulesApp() }
    }
}

@Composable
fun MeetpulesApp() {
    var tab by remember { mutableStateOf("Discover") }
    var page by remember { mutableStateOf("main") }
    var selectedName by remember { mutableStateOf("Aarohi") }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Gold, onPrimary = Black, background = Black, surface = Panel,
        onSurface = Color.White, secondary = GoldLight
    )) {
        Surface(Modifier.fillMaxSize(), color = Black) {
            if (page == "call") {
                CallScreen(selectedName, onBack = { page = "main" })
            } else {
                Column(Modifier.fillMaxSize()) {
                    if (page == "main") {
                        Header()
                        Box(Modifier.weight(1f).fillMaxWidth()) {
                            when (tab) {
                                "Discover" -> DiscoverScreen(
                                    onLike = { selectedName = it },
                                    onVideo = { selectedName = it; page = "call" }
                                )
                                "Matches" -> MatchesScreen(onOpen = { selectedName = it; tab = "Chat" })
                                "Chat" -> ChatScreen()
                                else -> ProfileScreen()
                            }
                        }
                        BottomBar(tab) { tab = it }
                    } else {
                        ProfileScreen()
                    }
                }
            }
        }
    }
}

@Composable
fun Header() {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text("Meetpules", color = GoldLight, fontSize = 27.sp, fontWeight = FontWeight.ExtraBold)
            Text("MEET • MATCH • CONNECT", color = Muted, fontSize = 9.sp, letterSpacing = 2.sp)
        }
        Surface(shape = CircleShape, color = Panel, modifier = Modifier.size(42.dp)) {
            Box(contentAlignment = Alignment.Center) {
                Icon(Icons.Default.NotificationsNone, null, tint = Gold)
            }
        }
    }
}

@Composable
fun DiscoverScreen(onLike: (String) -> Unit, onVideo: (String) -> Unit) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 18.dp, vertical = 6.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Discover", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                    Text("Find someone worth smiling for", color = Muted, fontSize = 13.sp)
                }
                AssistChip(onClick = {}, label = { Text("Lucknow  ⌄", color = Gold) },
                    colors = AssistChipDefaults.assistChipColors(containerColor = Panel))
            }
        }
        item { ProfileCard("Aarohi", "24", "Lucknow", "Travel • Music • Coffee", onLike, onVideo) }
        item { ProfileCard("Riya", "26", "Kanpur", "Books • Food • Art", onLike, onVideo) }
        item { ProfileCard("Ananya", "23", "Lucknow", "Movies • Fitness • Nature", onLike, onVideo) }
        item {
            Text("Demo profiles only. Real profiles will appear after backend and verification are connected.",
                color = Muted, fontSize = 11.sp, textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth().padding(8.dp))
        }
    }
}

@Composable
fun ProfileCard(name: String, age: String, city: String, bio: String,
                onLike: (String) -> Unit, onVideo: (String) -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = Panel)
    ) {
        Column {
            Box(
                Modifier.fillMaxWidth().height(205.dp)
                    .background(Brush.linearGradient(listOf(Color(0xFF49371D), Color(0xFF17120B), Color(0xFF252525)))),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Default.Person, null, tint = Gold.copy(alpha = .8f), modifier = Modifier.size(92.dp))
                Surface(
                    color = Color(0xCC090909), shape = RoundedCornerShape(30.dp),
                    modifier = Modifier.align(Alignment.BottomStart).padding(14.dp)
                ) {
                    Text("  ●  NEW HERE  ", color = GoldLight, fontSize = 10.sp, modifier = Modifier.padding(5.dp))
                }
            }
            Column(Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("$name, $age", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.width(8.dp))
                    Icon(Icons.Default.Verified, null, tint = Gold, modifier = Modifier.size(17.dp))
                }
                Text("⌖ $city  •  $bio", color = Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
                Spacer(Modifier.height(14.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedButton(onClick = { onLike(name) }, modifier = Modifier.weight(1f),
                        border = BorderStroke(1.dp, Gold)) {
                        Icon(Icons.Default.FavoriteBorder, null, tint = Gold)
                        Spacer(Modifier.width(6.dp)); Text("Like", color = Gold)
                    }
                    Button(onClick = { onVideo(name) }, modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = Gold)) {
                        Icon(Icons.Default.Videocam, null, tint = Black)
                        Spacer(Modifier.width(6.dp)); Text("Video Call", color = Black)
                    }
                }
            }
        }
    }
}

@Composable
fun MatchesScreen(onOpen: (String) -> Unit) {
    Column(Modifier.fillMaxWidth().padding(20.dp)) {
        Text("Your Matches", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Text("People who liked you back will show here.", color = Muted, fontSize = 13.sp)
        Spacer(Modifier.height(18.dp))
        listOf("Aarohi", "Riya", "Ananya").forEach { name ->
            Row(Modifier.fillMaxWidth().padding(vertical = 8.dp).background(Panel, RoundedCornerShape(16.dp))
                .clickable { onOpen(name) }.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                Surface(Modifier.size(48.dp), shape = CircleShape, color = Color(0xFF49371D)) {
                    Box(contentAlignment = Alignment.Center) { Icon(Icons.Default.Person, null, tint = Gold) }
                }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(name, color = Color.White, fontWeight = FontWeight.SemiBold)
                    Text("Demo match", color = Muted, fontSize = 11.sp)
                }
                Icon(Icons.Default.ChevronRight, null, tint = Gold)
            }
        }
    }
}

@Composable
fun ChatScreen() {
    Column(Modifier.fillMaxSize().padding(20.dp)) {
        Text("Messages", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Text("Your conversations in one place", color = Muted, fontSize = 13.sp)
        Spacer(Modifier.height(22.dp))
        Box(Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(Icons.Default.Forum, null, tint = Gold, modifier = Modifier.size(48.dp))
                Spacer(Modifier.height(12.dp))
                Text("No messages yet", color = Color.White, fontWeight = FontWeight.SemiBold)
                Text("Match with someone to start chatting.", color = Muted, fontSize = 12.sp)
            }
        }
    }
}

@Composable
fun ProfileScreen() {
    Column(Modifier.fillMaxSize().padding(20.dp)) {
        Text("My Profile", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(18.dp))
        Box(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(22.dp)).padding(22.dp),
            contentAlignment = Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Surface(Modifier.size(86.dp), shape = CircleShape, color = Color(0xFF49371D)) {
                    Box(contentAlignment = Alignment.Center) { Icon(Icons.Default.Person, null, tint = Gold, modifier = Modifier.size(48.dp)) }
                }
                Spacer(Modifier.height(12.dp))
                Text("Your name", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Text("Add your bio and photos to get started", color = Muted, fontSize = 12.sp)
            }
        }
        Spacer(Modifier.height(18.dp))
        listOf("Edit profile", "Verification", "Privacy & safety", "Membership", "Settings").forEach {
            Row(Modifier.fillMaxWidth().padding(vertical = 5.dp).background(Panel, RoundedCornerShape(12.dp)).padding(15.dp),
                verticalAlignment = Alignment.CenterVertically) {
                Text(it, color = Color.White, modifier = Modifier.weight(1f))
                Icon(Icons.Default.ChevronRight, null, tint = Gold)
            }
        }
    }
}

@Composable
fun CallScreen(name: String, onBack: () -> Unit) {
    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF382A13), Black)))) {
        Column(Modifier.align(Alignment.Center), horizontalAlignment = Alignment.CenterHorizontally) {
            Surface(Modifier.size(124.dp), shape = CircleShape, color = Color(0xFF49371D)) {
                Box(contentAlignment = Alignment.Center) { Icon(Icons.Default.Person, null, tint = Gold, modifier = Modifier.size(70.dp)) }
            }
            Spacer(Modifier.height(18.dp))
            Text(name, color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Bold)
            Text("Video call preview", color = GoldLight, fontSize = 13.sp)
            Spacer(Modifier.height(8.dp))
            Text("Calling is a UI preview. Live video requires a calling provider and secure backend.",
                color = Muted, fontSize = 11.sp, textAlign = TextAlign.Center, modifier = Modifier.padding(horizontal = 34.dp))
        }
        Row(Modifier.align(Alignment.BottomCenter).padding(bottom = 48.dp), horizontalArrangement = Arrangement.spacedBy(22.dp)) {
            CallControl(Icons.Default.MicOff, "Mute") {}
            CallControl(Icons.Default.VideocamOff, "Camera") {}
            CallControl(Icons.Default.CallEnd, "End", onBack, danger = true)
        }
    }
}

@Composable
fun CallControl(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, onClick: () -> Unit, danger: Boolean = false) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Surface(Modifier.size(58.dp).clickable { onClick() }, shape = CircleShape,
            color = if (danger) Color(0xFFB3261E) else Panel) {
            Box(contentAlignment = Alignment.Center) { Icon(icon, null, tint = Color.White) }
        }
        Spacer(Modifier.height(6.dp))
        Text(label, color = Color.White, fontSize = 11.sp)
    }
}

@Composable
fun BottomBar(selected: String, onSelect: (String) -> Unit) {
    NavigationBar(containerColor = Color(0xFF111111), contentColor = Gold) {
        listOf(
            Triple("Discover", Icons.Default.Explore, "Discover"),
            Triple("Matches", Icons.Default.Favorite, "Matches"),
            Triple("Chat", Icons.Default.ChatBubbleOutline, "Chat"),
            Triple("Profile", Icons.Default.PersonOutline, "Profile")
        ).forEach { (label, icon, route) ->
            NavigationBarItem(
                selected = selected == route,
                onClick = { onSelect(route) },
                icon = { Icon(icon, contentDescription = label) },
                label = { Text(label, fontSize = 10.sp) },
                colors = NavigationBarItemDefaults.colors(selectedIconColor = Gold, selectedTextColor = Gold,
                    unselectedIconColor = Muted, unselectedTextColor = Muted, indicatorColor = Color(0xFF302515))
            )
        }
    }
}
