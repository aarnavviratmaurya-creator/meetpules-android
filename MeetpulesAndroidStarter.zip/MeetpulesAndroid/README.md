# Meetpules Android starter

A black-and-gold Android UI starter for the Meetpules dating app.

## Included in this first prototype
- Discover feed with demo profile cards
- Like and video-call entry points
- Matches, chat, and profile tabs
- Video-call preview screen
- Black & Gold premium theme

## Open and run
1. Install Android Studio (current stable version).
2. Open this folder as a project.
3. Allow Gradle sync to finish.
4. Run on an Android device or emulator (Android 8.0 / API 26 or newer).

## Important: what is not connected yet
This is a UI starter, not a production dating service. Demo profiles and buttons are local placeholders. Live video/audio calling, login/OTP, real chat, matching, photo upload, push notifications, subscriptions/payments, moderation, and database storage need backend services and provider credentials.

Before public launch, implement:
- 18+ age checks and identity/profile verification
- consent-based calling, block/report, moderation and abuse handling
- privacy policy, terms, account deletion, data retention and secure storage
- server-side authorization and payment validation

Suggested next implementation milestone: authentication + profile database, then real-time chat and video calling (for example, through a video SDK such as Agora or ZEGOCLOUD).
